package View.Menu;

/**
 * The interface Menu choices is used to make different menus out of enums.
 */
public interface MenuChoices {
    int getValue();
    String getMenuString();


}
